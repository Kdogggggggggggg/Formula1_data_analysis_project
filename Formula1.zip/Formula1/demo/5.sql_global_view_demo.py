# Databricks notebook source
# MAGIC %md 
# MAGIC #### Global variable was made in 4.sql_temp_view_demo
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from global_temp.gv_race_results;